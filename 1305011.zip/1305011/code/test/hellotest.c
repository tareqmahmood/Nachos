#include "syscall.h"

int main()
{
	Write("Hello World\n", 12, 0);
	Exit(0);
}