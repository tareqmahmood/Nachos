cd ..
make
cd threads
echo ---------- OUTPUT -----------------
./nachos -rs threadtest
