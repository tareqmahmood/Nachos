cd userprog
gmake depend
