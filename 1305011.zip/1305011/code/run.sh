cd userprog
./nachos -x ../test/$1
