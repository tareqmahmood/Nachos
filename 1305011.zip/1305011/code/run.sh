cd userprog
./nachos -rs 80 -x ../test/try
