cd test
gmake $1
