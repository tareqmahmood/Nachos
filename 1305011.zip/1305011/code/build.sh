cd threads
make
cd ../userprog
make
