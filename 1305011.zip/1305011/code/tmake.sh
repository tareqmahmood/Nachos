cd threads
gmake depend
